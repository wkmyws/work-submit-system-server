// 压缩打包文件
var zipper = require("zip-local");
zipper.sync.zip("./").compress().save("./target.zip");