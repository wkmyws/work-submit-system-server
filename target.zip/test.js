const base62x = require('base62x')

console.log(new Date().getTime())